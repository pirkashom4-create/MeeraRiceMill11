MEERA BROKER AND TRADER'S - Android Source v1.8 BLUE UI REDESIGN
یہ Android Studio source project ہے، APK نہیں۔

اس ورژن میں:
- مکمل Navy Blue + White + Light Blue visual theme
- ہر صفحے پر نیا صاف header اور بہتر typography
- Rounded input fields, dropdowns اور modern blue action buttons
- Dashboard پر Welcome section اور Mill Operations grouping
- Existing SQLite database، tables اور business modules برقرار رکھے گئے ہیں
- Existing Gate Pass, Stock, Feeding, Production, Sale/Purchase, Ledger, Payment, Backup/Restore اور Reports کے methods برقرار ہیں

اہم:
- اس source کو نئی APK بنانے کے لیے GitHub repository میں upload کریں۔
- GitHub Actions میں Build Android APK workflow کو Success ہونا چاہیے۔
- یہ source package ہے؛ اس ماحول میں Android SDK/Gradle دستیاب نہ ہونے کی وجہ سے APK build یا device testing نہیں ہو سکی۔
- نیا APK install کرنے سے پہلے موجودہ app کا Backup Data ضرور بنائیں۔
- یہ ابھی prototype ہے؛ کاروباری استعمال سے پہلے تمام entries، reports، PDF اور backup/restore کو اچھی طرح test کریں۔

نیا اکاؤنٹنگ ماڈیول (v1.9 source update):
- Party Account Feeding: پارٹی/اکاؤنٹ نام، قسم، اوپننگ بیلنس اور Debit/Credit opening side محفوظ کریں۔
- Journal Voucher: Debit Account، Credit Account، رقم اور تفصیل درج کریں۔ دونوں اکاؤنٹس پہلے بنے ہوئے ہونے چاہئیں؛ ایک ہی رقم دونوں طرف پوسٹ ہوتی ہے۔
- Journal Voucher History اور Account Ledger میں JV entries دیکھی جا سکتی ہیں۔
- ڈیٹا SQLite میں آف لائن محفوظ ہوتا ہے۔
اہم: یہ Android Studio source project ہے، APK نہیں۔ اس اپ ڈیٹ کو فون پر حقیقی کاروباری ڈیٹا ڈالنے سے پہلے build، install اور مکمل حسابی ٹیسٹ کرنا ضروری ہے۔
